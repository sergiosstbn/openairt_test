import json
import logging
from enum import Enum
from typing import Any, Callable, Optional

from fastapi import WebSocket, WebSocketDisconnect
from azure.core.credentials import AzureKeyCredential
from azure.identity import DefaultAzureCredential, get_bearer_token_provider
import asyncio
import websockets

logger = logging.getLogger("voicerag")


class RealtimeMessageRelay:
    """
    Manages WebSocket communication between a client and an external server (e.g., OpenAI, Azure OAI).

    This class acts as a relay for bidirectional communication, processes messages, 
    and integrates tools for enhanced functionality.

    Attributes:
        endpoint (str): The server endpoint for WebSocket communication.
        deployment (str): The deployment configuration.
        key (Optional[str]): The API key for authentication, if used.
        voice_choice (Optional[str]): Choice of voice configuration, if applicable.
        api_version (str): API version for server communication.
        tools (dict[str, Tool]): A dictionary of available tools for message processing.
    """

    def __init__(
        self,
        endpoint: str,
        deployment: str,
        credentials: AzureKeyCredential | DefaultAzureCredential,
        voice_choice: Optional[str] = None,
    ):
        """
        Initializes the RealtimeMessageRelay.

        Args:
            endpoint (str): The server WebSocket endpoint.
            deployment (str): Deployment name or configuration.
            credentials (Union[AzureKeyCredential, DefaultAzureCredential]): Credentials for API authentication.
            voice_choice (Optional[str]): Choice of voice configuration (optional).
        """
        self.endpoint = endpoint
        self.deployment = deployment
        self.voice_choice = voice_choice
        self.key = credentials.key if isinstance(credentials, AzureKeyCredential) else None
        self._token_provider = (
            get_bearer_token_provider(credentials, "https://cognitiveservices.azure.com/.default")
            if not self.key
            else None
        )
        self._tools_pending = {}
        self.tools = {}
        self.api_version = "2024-10-01-preview"
        logger.info("Realtime voice choice set to %s", voice_choice)

    async def _process_message_to_client(
        self, msg: str, client_ws: WebSocket, server_ws: websockets.WebSocketClientProtocol
    ) -> Optional[str]:
        """
        Processes messages coming from the server to the client.

        Args:
            msg (str): The raw message received from the server.
            client_ws (WebSocket): The client WebSocket connection.
            server_ws (websockets.WebSocketClientProtocol): The server WebSocket connection.

        Returns:
            Optional[str]: The updated message to be forwarded, or None if suppressed.
        """
        message = json.loads(msg)
        updated_message = msg

        if message and message["type"] == "session.created":
            session = message["session"]
            session["instructions"] = ""
            session["tools"] = []
            session["voice"] = self.voice_choice
            session["tool_choice"] = "none"
            updated_message = json.dumps(message)

        return updated_message

    async def _process_message_to_server(self, msg: str) -> Optional[str]:
        """
        Processes messages coming from the client to the server.

        Args:
            msg (str): The raw message received from the client.

        Returns:
            Optional[str]: The updated message to be forwarded, or None if suppressed.
        """
        message = json.loads(msg)
        updated_message = msg

        if message and message["type"] == "session.update":
            session = message["session"]
            session["tool_choice"] = "auto" if self.tools else "none"
            session["tools"] = [tool.schema for tool in self.tools.values()]
            updated_message = json.dumps(message)

        return updated_message

    async def _relay_messages(self, client_ws: WebSocket):
        """
        Handles bidirectional message forwarding between client and server.

        Args:
            client_ws (WebSocket): The client WebSocket connection.
        """
        headers = {"Authorization": f"Bearer {self._token_provider()}" if self._token_provider else f"api-key {self.key}"}
        uri = f"{self.endpoint}/openai/realtime?api-version={self.api_version}&deployment={self.deployment}"

        async with websockets.connect(uri, extra_headers=headers) as server_ws:
            async def from_client_to_server():
                async for data in client_ws.iter_text():
                    new_msg = await self._process_message_to_server(data)
                    if new_msg:
                        await server_ws.send(new_msg)

            async def from_server_to_client():
                async for msg in server_ws:
                    new_msg = await self._process_message_to_client(msg, client_ws, server_ws)
                    if new_msg:
                        await client_ws.send_text(new_msg)

            await asyncio.gather(from_client_to_server(), from_server_to_client())

    async def websocket_handler(self, websocket: WebSocket):
        """
        Entry point to handle WebSocket connections.

        Args:
            websocket (WebSocket): The client WebSocket connection.
        """
        await websocket.accept()
        try:
            await self._relay_messages(websocket)
        except WebSocketDisconnect:
            logger.info("Client disconnected")
        except Exception as e:
            logger.error(f"WebSocket error: {e}")
        finally:
            await websocket.close()
            logger.info("WebSocket closed")


class ToolResultDirection(Enum):
    """
    Enum to specify the direction of a tool result.

    Attributes:
        TO_SERVER (int): Indicates the tool result is sent to the server.
        TO_CLIENT (int): Indicates the tool result is sent to the client.
    """
    TO_SERVER = 1
    TO_CLIENT = 2


class ToolResult:
    """
    Represents the result of a tool execution.

    Attributes:
        text (str): The output of the tool execution.
        destination (ToolResultDirection): The direction where the result should be sent.
    """

    def __init__(self, text: str, destination: ToolResultDirection):
        self.text = text
        self.destination = destination

    def to_text(self) -> str:
        return "" if self.text is None else (self.text if isinstance(self.text, str) else json.dumps(self.text))


class Tool:
    """
    Represents a tool with a target function and schema.

    Attributes:
        target (Callable): The function to execute the tool.
        schema (Any): The schema that defines the tool.
    """

    def __init__(self, target: Callable[..., ToolResult], schema: Any):
        self.target = target
        self.schema = schema


class RTToolCall:
    """
    Represents a tool call made during message processing.

    Attributes:
        tool_call_id (str): The unique identifier for the tool call.
        previous_id (str): The identifier for the previous message.
    """

    def __init__(self, tool_call_id: str, previous_id: str):
        self.tool_call_id = tool_call_id
        self.previous_id = previous_id


